public class MainHewan {
    public static void main(String[] args) {
        Hewan hewan1 = new Hewan("Kucing", "Mamalia", "Nyann~~");
        Hewan hewan2 = new Hewan("Anjing", "Mamalia", "Woof-woof!!");

        hewan1.tampilkanInfo();
        hewan2.tampilkanInfo();

    }
}